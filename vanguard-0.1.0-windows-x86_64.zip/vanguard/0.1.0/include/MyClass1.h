// MyClass1.h
#pragma once

class MyClass1 {
public:
    void doSomething();
};
